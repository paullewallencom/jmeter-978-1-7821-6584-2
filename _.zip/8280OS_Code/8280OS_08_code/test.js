var links = new Array();
links.push("<a href='#'>hello world 1</a>");
links.push("<a href='#'>hello world 2</a>");
links.push("<a href='#'>hello world 3</a>");
links.push("<a href='#'>hello world 4</a>");

for (int i = 0; i < links.length; i++) {
	//vars.putObject("js_link_" + i, links[i]);
	console.log(links[i]);
}