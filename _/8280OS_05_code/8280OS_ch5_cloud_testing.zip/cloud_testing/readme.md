### Sample script to use for Chapter 5

Contains **shoutbox_loop.jmx** test script to use for recipes contained in Chapter 5.
